from fastapi import FastAPI
from models.models import User
from models.models import Feedback

app = FastAPI()

# Создаем экземпляр класса User
user = User(name="John Doe", id=1)

feedback_store = [] #список для хранения отзывов

@app.get("/")
async def root():
    return {"message": "Добро пожаловать в API пользователей"}

@app.get("/users")
async def get_user():
    """
    GET-эндпоинт для получения информации о пользователе.
    Возвращает JSON с данными пользователя.
    """
    return {
        "user": user,
        "status": "success",
        "message": "Данные пользователя успешно получены"
    }

@app.post("/feedback")
async def submit_feedback(feedback: Feedback):
    #это пост-эдпоин для получения обратной связи от
    #пользователей

    feedback_store.append(feedback)
    
    return{
        "message": f"Обратная связь получена.{feedback.name}"
    }

#uvicorn main:app --reload
#http://127.0.0.1:8000

#models.py: Содержит Pydantic модель User с обязательными полями name (строка) и id (целое число).


# Импортирует модель User из models.py

# Создает экземпляр класса User с указанными значениями

# Реализует GET-эндпоинт /users, который возвращает JSON с данными пользователя

# FastAPI автоматически сериализует объект User в JSON благодаря встроенной поддержке Pydantic моделей.

#curl.exe -X POST "http://127.0.0.1:8000/calculate" -H "Content-Type: application/json" -d '{\"num1\":5,\"num2\":10}'

#http POST http://127.0.0.1:8000/feedback name="Дима" message="Привет!"

#curl -X POST "http://127.0.0.1:8000/feedback" -H "Content-Type: application/json" -d "{\"name\": \"Дима\", \"message\": \"Привет, как дела?!\"}"